#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import serial
import threading
import time


class DataEspNode(Node):
    def __init__(self):
        super().__init__('esp_node')  # Nama node ROS 2

        # Deklarasi parameter untuk koneksi serial
        self.declare_parameter('serial_port', '/dev/ttyUSB0')
        self.declare_parameter('baud_rate', 115200)
        self.declare_parameter('timeout', 1.0)
        self.declare_parameter('reconnect_delay', 5.0)

        # Mengambil nilai parameter
        self.serial_port = self.get_parameter('serial_port').get_parameter_value().string_value
        self.baud_rate = self.get_parameter('baud_rate').get_parameter_value().integer_value
        self.timeout = self.get_parameter('timeout').get_parameter_value().double_value
        self.reconnect_delay = self.get_parameter('reconnect_delay').get_parameter_value().double_value

        # Membuat publisher untuk topik ROS 2
        self.publisher = self.create_publisher(String, '/esp32_data', 10)

        # Inisialisasi koneksi serial
        self.serial_connection = None
        self.running = True

        # Thread untuk menangani koneksi serial
        self.thread = threading.Thread(target=self.serial_handler)
        self.thread.daemon = True
        self.thread.start()

        self.get_logger().info(
            f'DataEsp Node diinisialisasi pada port {self.serial_port} dengan baud rate {self.baud_rate}'
        )

    def serial_handler(self):
        """Fungsi untuk menangani koneksi serial dalam thread terpisah."""
        while self.running:
            try:
                # Jika koneksi belum ada, coba hubungkan
                if self.serial_connection is None or not self.serial_connection.is_open:
                    self.connect_serial()

                # Membaca data dari koneksi serial jika terbuka
                if self.serial_connection and self.serial_connection.is_open:
                    self.read_serial_data()
                else:
                    time.sleep(self.reconnect_delay)
            except Exception as e:
                self.get_logger().error(f'Error dalam serial handler: {e}')
                self.disconnect_serial()
                time.sleep(self.reconnect_delay)

    def connect_serial(self):
        """Membuka koneksi serial ke ESP32."""
        try:
            self.get_logger().info(f'Mencoba menghubungkan ke {self.serial_port}...')
            self.serial_connection = serial.Serial(
                port=self.serial_port,
                baudrate=self.baud_rate,
                timeout=self.timeout
            )
            if self.serial_connection.is_open:
                self.get_logger().info(f'Berhasil terhubung ke {self.serial_port}')
            else:
                self.get_logger().error(f'Gagal membuka {self.serial_port}')
        except serial.SerialException as e:
            self.get_logger().error(f'Error koneksi serial: {e}')
            self.serial_connection = None

    def disconnect_serial(self):
        """Menutup koneksi serial dengan aman."""
        if self.serial_connection and self.serial_connection.is_open:
            try:
                self.serial_connection.close()
                self.get_logger().info('Koneksi serial ditutup')
            except Exception as e:
                self.get_logger().error(f'Error menutup koneksi serial: {e}')
        self.serial_connection = None

    def read_serial_data(self):
        """Membaca data dari serial, memproses, dan mencetak hasil ke terminal."""
        try:
            if self.serial_connection.in_waiting > 0:
                # Membaca satu baris data dari serial
                raw_data = self.serial_connection.readline().decode('utf-8').strip()

                if raw_data:
                    # Log data mentah yang diterima
                    self.get_logger().debug(f'Data diterima dari ESP32: {raw_data}')

                    # FILTER: Hanya proses data yang dimulai dengan '*' dan diakhiri '#'
                    # dan memiliki 22 elemen (data sensor), bukan data motor
                    if self.is_sensor_data(raw_data):
                        # Proses data dan cetak ke terminal
                        self.process_and_print_data(raw_data)

                        # Publikasikan data ke topik ROS 2
                        msg = String()
                        msg.data = raw_data
                        self.publisher.publish(msg)
                    else:
                        # Abaikan data motor atau data yang tidak valid
                        self.get_logger().debug(f'Data diabaikan (bukan data sensor): {raw_data}')
        except serial.SerialException as e:
            self.get_logger().error(f'Error membaca data serial: {e}')
            self.disconnect_serial()
        except UnicodeDecodeError as e:
            self.get_logger().warn(f'Error decoding data serial: {e}')
        except Exception as e:
            self.get_logger().error(f'Error tidak terduga saat membaca data serial: {e}')

    def is_sensor_data(self, data):
        """Memeriksa apakah data adalah data sensor yang valid (bukan data motor)."""
        try:
            # Pastikan data sesuai format "*...#"
            if not (data.startswith('*') and data.endswith('#')):
                return False

            # Ambil isi data tanpa pembatas "*...#"
            content = data[1:-1]

            # Split menjadi elemen-elemen terpisah
            parts = content.split(' ')
            
            # Data sensor harus memiliki 22 elemen
            if len(parts) != 22:
                return False
            
            # Periksa apakah ini data motor (hanya 2 elemen numerik)
            # Data motor biasanya seperti "*512 512#" atau "*1024 0#"
            if len(parts) == 2:
                try:
                    # Jika kedua elemen adalah angka dan dalam rentang motor (0-1024)
                    val1 = int(parts[0])
                    val2 = int(parts[1])
                    if 0 <= val1 <= 1024 and 0 <= val2 <= 1024:
                        return False  # Ini data motor, bukan sensor
                except ValueError:
                    pass
            
            # Validasi tambahan: elemen ke-14 dan ke-15 harus 4 digit (dataPWM1 dan dataPWM2)
            if len(parts[14]) == 4 and len(parts[15]) == 4:
                try:
                    int(parts[14])  # dataPWM1
                    int(parts[15])  # dataPWM2
                    return True
                except ValueError:
                    return False
            
            return False
        except Exception:
            return False

    def process_and_print_data(self, data):
        """Memproses data dari ESP32 dan mencetaknya ke terminal dalam format yang diinginkan."""
        try:
            # Ambil isi data tanpa pembatas "*...#"
            content = data[1:-1]

            # Split menjadi elemen-elemen terpisah
            parts = content.split(' ')
            if len(parts) != 22:  # Memperbarui jumlah elemen karena ada 2 data tambahan
                self.get_logger().warn(f'Jumlah data tidak valid: {data}')
                return

            # Parse data ke dalam variabel
            Segitiga = parts[0]
            Bulat = parts[1]
            Silang = parts[2]
            Kotak = parts[3]
            Atas = parts[4]
            Kanan = parts[5]
            Bawah = parts[6]
            Kiri = parts[7]
            L1 = parts[8]
            L2 = parts[9]
            R1 = parts[10]
            R2 = parts[11]
            Select = parts[12]
            Start = parts[13]
            dataPWM1 = parts[14]
            dataPWM2 = parts[15]
            DataLY = parts[16]
            DataLX = parts[17]
            DataRY = parts[18]
            DataRX = parts[19]
            dataJarak = parts[20]  # Data Jarak
            dataAngle = parts[21]  # Data Angle

            # Cetak data dalam format yang diinginkan
            print(f"Segitiga : {Segitiga}")
            print(f"Bulat    : {Bulat}")
            print(f"Silang   : {Silang}")
            print(f"Kotak    : {Kotak}")
            print(f"Atas     : {Atas}")
            print(f"Kanan    : {Kanan}")
            print(f"Bawah    : {Bawah}")
            print(f"Kiri     : {Kiri}")
            print(f"L1       : {L1}")
            print(f"L2       : {L2}")
            print(f"R1       : {R1}")
            print(f"R2       : {R2}")
            print(f"Select   : {Select}")
            print(f"Start    : {Start}")
            print(f"dataPWM1 : {dataPWM1}")
            print(f"dataPWM2 : {dataPWM2}")
            print(f"DataLY   : {DataLY}")
            print(f"DataLX   : {DataLX}")
            print(f"DataRY   : {DataRY}")
            print(f"DataRX   : {DataRX}")
            print(f"Jarak    : {dataJarak}")  # Menampilkan Data Jarak
            print(f"Angle    : {dataAngle}")  # Menampilkan Data Angle
            print("-" * 40)  # Garis pemisah untuk memudahkan pembacaan
        except Exception as e:
            self.get_logger().error(f'Error memproses data: {e}')

    def destroy_node(self):
        """Fungsi untuk membersihkan koneksi saat node ditutup."""
        self.running = False
        self.disconnect_serial()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)

    try:
        # Membuat dan menjalankan node
        node = DataEspNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()


if __name__ == '__main__':
    main()