#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import math
import serial
import time
import threading
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Pose, Quaternion
from tf2_ros import TransformBroadcaster, TransformStamped
import math


def constrain(value, min_val, max_val):
    return max(min(value, max_val), min_val)


def smoothSpeed(current_speed, target_speed, increment):
    if target_speed > current_speed:
        current_speed += increment
        if current_speed > target_speed:
            current_speed = target_speed
    else:
        current_speed -= increment
        if current_speed < target_speed:
            current_speed = target_speed
    return current_speed


def normalize_angle(angle):
    """Normalisasi angle ke range -180 sampai 180 derajat."""
    while angle > 180:
        angle -= 360
    while angle < -180:
        angle += 360
    return angle


class PIDController:
    def __init__(self, kp, ki, kd, max_output=400):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.max_output = max_output
        self.prev_error = 0
        self.integral = 0
        self.last_time = 0
        
    def calculate(self, setpoint, current_value, dt):
        error = setpoint - current_value
        
        # Anti-windup untuk integral
        if abs(error) < 10:
            self.integral += error * dt
            # Batasi integral
            self.integral = constrain(self.integral, -100, 100)
        else:
            self.integral *= 0.8
        
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        
        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        output = constrain(output, -self.max_output, self.max_output)
        
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0


class OlahNode(Node):
    def __init__(self, mode):
        super().__init__('olah_node')
        
        # Inisialisasi publisher untuk Odometry
        self.odom_publisher = self.create_publisher(Odometry, '/odom', 10)

        # Inisialisasi transform broadcaster
        self.tf_broadcaster = TransformBroadcaster(self)

        # Variabel untuk posisi robot dan odometry
        self.pose = Pose()
        self.pose.position.x = 0.0
        self.pose.position.y = 0.0
        self.pose.position.z = 0.0
        self.pose.orientation.w = 1.0  # Orientasi awal (tidak ada rotasi)
        
        # Robot physical parameters
        self.wheel_base = 0.5  # Jarak antar roda dalam meter (sesuaikan dengan robot Anda)
        self.wheel_radius = 0.05  # Radius roda dalam meter (sesuaikan dengan robot Anda)
        
        # Store last motor commands for odometry
        self.last_motor_left = 512
        self.last_motor_right = 512
        self.robot_heading = 0.0  # Robot heading in radians

        # Waktu awal untuk delta_time
        self.last_time = time.time()

        # Mode operasi
        self.current_mode = mode
        self.menu_mode = True  # Start di menu
        
        # Subscriber untuk data ESP32
        self.subscription = self.create_subscription(
            String,
            '/esp32_data',
            self.esp32_data_callback,
            10
        )
        
        # Subscriber untuk deteksi objek
        self.object_subscription = self.create_subscription(
            String,
            '/object_status',
            self.object_detection_callback,
            10
        )
        
        # Parameter serial ke ESP32
        self.declare_parameter('serial_port', '/dev/ttyUSB0')
        self.declare_parameter('baud_rate', 115200)
        
        self.serial_port = self.get_parameter('serial_port').get_parameter_value().string_value
        self.baud_rate = self.get_parameter('baud_rate').get_parameter_value().integer_value
        
        # Inisialisasi koneksi serial
        try:
            self.serial_connection = serial.Serial(
                port=self.serial_port,
                baudrate=self.baud_rate,
                timeout=1
            )
            self.get_logger().info(f'Terhubung ke ESP32 pada port {self.serial_port}')
        except serial.SerialException as e:
            self.get_logger().error(f'Gagal menghubungkan ke ESP32: {e}')
            self.serial_connection = None
        
        # Variabel robot
        self.angle = 0
        self.distance = 0
        
        # ENHANCED PWM Configuration - PWM selalu positif (0-1024)
        self.NEUTRAL_PWM = 512
        self.MIN_MOVEMENT_PWM = 300      # PWM minimum untuk gerakan
        self.MAX_PWM_RANGE = 550         # Range maksimum dari neutral (512±450) = 62-962
        self.BASE_SPEED = 400            # Base speed untuk gerakan normal 
        self.TURN_SPEED = 400            # Speed untuk turning
        self.APPROACH_SPEED_FAST = 400   # Speed cepat untuk approach jarak jauh
        self.APPROACH_SPEED_SLOW = 350   # Speed lambat untuk approach jarak dekat
        self.ALIGN_SPEED = 380           # Speed untuk alignment
        
        # SIMPLE: 90-Degree Turn Configuration
        self.TURN_90_SPEED = 380         # Speed untuk 90-degree turn
        self.ANGLE_TOLERANCE = 5         # Toleransi angle dalam derajat
        self.MAX_TURN_TIME = 8.0         # Timeout untuk turn operation (detik)
        
        # Variabel mode otomatis - ENHANCED untuk responsivitas tinggi
        self.bottle_detected = 0
        self.object_position = "none"
        self.target_locked = False
        self.lock_start_time = 0
        self.lock_duration = 0.8         # Dipercepat ke 0.8 detik
        self.last_known_angle = 0
        self.recovery_mode = False
        self.scanning_mode = False
        self.scan_direction = 1
        self.scan_start_time = 0
        self.scan_duration = 1.5         # Durasi per arah scan dipercepat
        
        # ENHANCED approach state dengan target 5cm
        self.approach_state = "search"   # search, align, approach, fine_approach, arrived
        self.current_motor_left = self.NEUTRAL_PWM
        self.current_motor_right = self.NEUTRAL_PWM
        self.speed_smoothing = 0.6       # Smoothing lebih responsif
        
        # Distance thresholds - TARGET 5CM
        self.TARGET_DISTANCE = 5         # Target jarak 5cm
        self.STOP_DISTANCE = 3           # Jarak berhenti 3cm
        self.FINE_APPROACH_DISTANCE = 15 # Mulai fine approach pada 15cm
        self.FAST_APPROACH_DISTANCE = 50 # Approach cepat untuk jarak >50cm
        
        # PID Controllers - ENHANCED dengan output lebih besar
        self.turn_pid = PIDController(kp=3.0, ki=0.15, kd=0.8, max_output=400)
        self.distance_pid = PIDController(kp=2.5, ki=0.08, kd=0.3, max_output=350)
        
        # Timing - lebih responsif
        self.last_time = time.time()
        self.last_detection_time = time.time()
        self.detection_timeout = 1.5     # Timeout dipercepat ke 1.5 detik
        
        # State variables untuk mode switching dan button detection
        self.last_silang_state = False
        self.last_bulat_state = False
        self.last_select_state = False
        self.last_kanan_state = False    # NEW: Button state tracking
        self.last_kiri_state = False     # NEW: Button state tracking

        # NEW: 90-Degree Turn State Variables
        self.is_turning_90 = False       # Flag untuk tracking turn operation
        self.turn_start_angle = 0        # Angle awal saat mulai turn
        self.turn_target_angle = 0       # Target angle untuk turn
        self.turn_start_time = 0         # Waktu mulai turn untuk timeout
        self.turn_direction = 0          # 1 untuk kanan, -1 untuk kiri

        # Menu variables
        self.last_menu_display = 0
        self.menu_refresh_interval = 1.0
        
        # Counter untuk debugging
        self.debug_counter = 0
        
        self.get_logger().info(f'Robot dimulai dalam mode: {self.current_mode.upper()}')
        self.get_logger().info(f'Target jarak: {self.TARGET_DISTANCE}cm, PWM minimum: {self.MIN_MOVEMENT_PWM}')
        self.get_logger().info('Fitur Turn 90°: Tekan Kanan/Kiri untuk increment 90° setiap press')

    def esp32_data_callback(self, msg):
        """Callback untuk menerima data dari ESP32."""
        raw_data = msg.data
        parsed_data = self.parse_data(raw_data)
        
        if parsed_data:
            (Segitiga, Bulat, Silang, Kotak, Atas, Kanan, Bawah, Kiri,
             L1, L2, R1, R2, Select, Start, dataPWM1, dataPWM2,
             DataLY, DataLX, DataRY, DataRX, dataJarak, dataAngle) = parsed_data
            
            # Update data robot
            self.angle = dataAngle
            self.distance = dataJarak

            # Hitung delta_time
            current_time = time.time()
            delta_time = current_time - self.last_time
            self.last_time = current_time  # Update last_time
            
            # Handle mode switching
            self.handle_mode_switching(Silang, Bulat, Select)
            
            if self.menu_mode:
                self.send_default_data()
                return 
            
            # Panggil fungsi untuk update odometri
            self.update_odometry(delta_time)
        
            # Proses berdasarkan mode aktif
            if self.current_mode == 'manual' and not self.menu_mode:
                self.process_manual_mode(DataLY, DataLX, Kanan, Kiri)  # NEW: Tambah parameter Kanan, Kiri
            elif self.current_mode == 'auto' and not self.menu_mode:
                self.process_auto_mode()

    def object_detection_callback(self, msg):
        """Callback untuk menerima data deteksi objek."""
        try:
            data = msg.data.split(' ')
            self.bottle_detected = int(data[0])
            self.object_position = data[1] if len(data) > 1 else "none"
            confidence = float(data[2]) if len(data) > 2 else 0.0  # Ambil confidence dari data yang diterima
            
            # Update waktu deteksi dan state
            if self.bottle_detected == 1 and confidence >= 0.7:  # Hanya deteksi dengan confidence >= 0.7 yang diproses
                self.last_detection_time = time.time()
                self.last_known_angle = self.angle
                self.recovery_mode = False
                self.scanning_mode = False

                # ENHANCED state logic berdasarkan posisi dan jarak
                if self.object_position == "center":
                    if self.distance > self.FINE_APPROACH_DISTANCE:
                        self.approach_state = "approach"
                    elif self.distance > self.TARGET_DISTANCE:
                        self.approach_state = "fine_approach"
                    else:
                        self.approach_state = "arrived"
                else:
                    self.approach_state = "align"
                
                if not self.menu_mode:  
                    self.debug_counter += 1
                    if self.debug_counter % 10 == 0:  # Print setiap 10 deteksi
                        print(f"[DETECTION] Bottle: {self.bottle_detected}, Pos: {self.object_position}, "
                            f"Dist: {self.distance}cm, Confidence: {confidence}, State: {self.approach_state}")
            else:
                # Jika confidence rendah, objek diabaikan
                if not self.menu_mode:  
                    self.debug_counter += 1
                    if self.debug_counter % 10 == 0:  # Print setiap 10 deteksi
                        print(f"Confidence: {confidence}")
                          
        except Exception as e:
            self.get_logger().error(f"Error parsing object detection data: {e}")

    def handle_mode_switching(self, silang, bulat, select):
        """Handle switching antara mode dan menu."""
        # Edge detection untuk tombol
        silang_pressed = silang == 1 and not self.last_silang_state
        bulat_pressed = bulat == 1 and not self.last_bulat_state
        select_pressed = select == 1 and not self.last_select_state
        
        # Update state
        self.last_silang_state = silang == 1
        self.last_bulat_state = bulat == 1
        self.last_select_state = select == 1
        
        # Logic mode switching
        if select_pressed:
            self.menu_mode = True
            show_menu()
            self.get_logger().info("Kembali ke menu utama. Tekan Silang untuk Manual, Bulat untuk Otomatis")
            self.reset_auto_mode_variables()
            self.is_turning_90 = False  # Reset turn state
        
        elif silang_pressed and self.menu_mode:
            self.current_mode = 'manual'
            self.menu_mode = False
            self.get_logger().info("Mode MANUAL aktif - Gunakan joystick atau tekan Kanan/Kiri untuk turn 90° increment")
            
        elif bulat_pressed and self.menu_mode:
            self.current_mode = 'auto'
            self.menu_mode = False
            self.get_logger().info(f"Mode OTOMATIS aktif - Target: {self.TARGET_DISTANCE}cm")
            self.reset_auto_mode_variables()

    def process_manual_mode(self, data_ly, data_lx, kanan, kiri):
        """Proses mode manual dengan PWM yang diperbaiki dan fitur 90-degree turn sederhana."""
        
        # NEW: Handle 90-degree turn buttons dengan edge detection
        kanan_pressed = kanan == 1 and not self.last_kanan_state
        kiri_pressed = kiri == 1 and not self.last_kiri_state
        
        # Update button states
        self.last_kanan_state = kanan == 1
        self.last_kiri_state = kiri == 1
        
        # NEW: Check for 90-degree turn commands
        if kanan_pressed and not self.is_turning_90:
            self.start_simple_90_turn(1)  # 1 untuk kanan
            
        elif kiri_pressed and not self.is_turning_90:
            self.start_simple_90_turn(-1)  # -1 untuk kiri
        
        # NEW: Override dataLX jika sedang turn 90 derajat
        if self.is_turning_90:
            # Override dataLX untuk membuat robot turn
            if self.turn_direction == 1:  # Turn kanan
                data_lx_override = self.NEUTRAL_PWM + 400  # Full turn kanan
            else:  # Turn kiri
                data_lx_override = self.NEUTRAL_PWM - 400  # Full turn kiri
            
            # Check if target reached
            if self.check_turn_completed():
                self.is_turning_90 = False
                self.get_logger().info(f"Turn 90° completed! Current angle: {self.angle:.1f}°")
            
            # Use override values
            motor_speeds = self.rumus_kinematiks_improved(data_ly, data_lx_override)
        else:
            # Normal manual control dengan joystick
            motor_speeds = self.rumus_kinematiks_improved(data_ly, data_lx)
        
        # Format dan tampilkan
        motor_left_formatted = f"{motor_speeds['motor_left']:04d}"
        motor_right_formatted = f"{motor_speeds['motor_right']:04d}"
        
        mode_text = "TURN-90" if self.is_turning_90 else "MANUAL"
        if self.is_turning_90:
            direction_text = "KANAN" if self.turn_direction == 1 else "KIRI"
            angle_diff = abs(normalize_angle(self.angle - self.turn_start_angle))
            print(f"[{mode_text}-{direction_text}] Motor L:{motor_left_formatted} R:{motor_right_formatted} | "
                  f"Start:{self.turn_start_angle:.1f}° Now:{self.angle:.1f}° Progress:{angle_diff:.1f}°/90°")
        else:
            print(f"[{mode_text}] Motor Kiri: {motor_left_formatted}, Motor Kanan: {motor_right_formatted}")
        
        self.send_data_to_esp32(motor_speeds)

    
    def update_odometry(self, delta_time):
        """Update odometri untuk posisi dan orientasi robot berdasarkan motor speeds terakhir."""
        # Convert PWM to velocity (m/s) - this is an approximation
        # Assuming PWM range 0-1024 maps to -max_velocity to +max_velocity
        max_velocity = 1.0  # Maximum velocity in m/s (adjust based on your robot)
        
        # Convert PWM to normalized velocity (-1 to 1)
        left_pwm_normalized = (self.last_motor_left - self.NEUTRAL_PWM) / self.NEUTRAL_PWM
        right_pwm_normalized = (self.last_motor_right - self.NEUTRAL_PWM) / self.NEUTRAL_PWM
        
        # Convert to actual velocities
        v_left = -left_pwm_normalized * max_velocity  # Negative because left motor is reversed
        v_right = right_pwm_normalized * max_velocity
        
        # Calculate linear and angular velocities
        v = (v_left + v_right) / 2.0  # Linear velocity
        w = (v_left - v_right) / self.wheel_base  # Angular velocity
        
        # Update robot heading
        self.robot_heading += w * delta_time
        self.robot_heading = normalize_angle(self.robot_heading * 180.0 / math.pi) * math.pi / 180.0  # Keep in radians
        
        # Calculate position change
        delta_x = v * math.cos(self.robot_heading) * delta_time
        delta_y = v * math.sin(self.robot_heading) * delta_time
        
        # Update position
        self.pose.position.x += delta_x
        self.pose.position.y += delta_y
        
        # Convert heading to quaternion
        self.pose.orientation = self.quaternion_from_euler(0.0, 0.0, self.robot_heading)
        
        # Create and publish odometry message
        odom_msg = Odometry()
        odom_msg.header.stamp = self.get_clock().now().to_msg()
        odom_msg.header.frame_id = "odom"
        odom_msg.child_frame_id = "base_link"
        odom_msg.pose.pose = self.pose
        
        # Set velocities
        odom_msg.twist.twist.linear.x = v
        odom_msg.twist.twist.angular.z = w
        
        # Publish odometry
        self.odom_publisher.publish(odom_msg)
        
        # Broadcast transform
        transform = TransformStamped()
        transform.header.stamp = self.get_clock().now().to_msg()
        transform.header.frame_id = "odom"
        transform.child_frame_id = "base_link"
        
        transform.transform.translation.x = self.pose.position.x
        transform.transform.translation.y = self.pose.position.y
        transform.transform.translation.z = 0.0
        transform.transform.rotation = self.pose.orientation
        
        self.tf_broadcaster.sendTransform(transform)

    def quaternion_from_euler(self, roll, pitch, yaw):
        """Convert Euler angles to quaternion."""
        qx = math.sin(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) - math.cos(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        qy = math.cos(roll/2) * math.sin(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.cos(pitch/2) * math.sin(yaw/2)
        qz = math.cos(roll/2) * math.cos(pitch/2) * math.sin(yaw/2) - math.sin(roll/2) * math.sin(pitch/2) * math.cos(yaw/2)
        qw = math.cos(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        
        return Quaternion(x=qx, y=qy, z=qz, w=qw)

    def start_simple_90_turn(self, direction):
        """Mulai operasi 90-degree turn sederhana - increment angle target."""
        self.is_turning_90 = True
        self.turn_start_angle = self.angle
        self.turn_direction = direction
        self.turn_start_time = time.time()
        
        # Hitung target angle dengan increment 90 derajat
        angle_increment = 90 * direction  # +90 untuk kanan, -90 untuk kiri
        self.turn_target_angle = normalize_angle(self.turn_start_angle + angle_increment)
        
        direction_text = "KANAN" if direction == 1 else "KIRI"
        self.get_logger().info(f"Mulai turn 90° ke {direction_text}")
        self.get_logger().info(f"Start: {self.turn_start_angle:.1f}° → Target: {self.turn_target_angle:.1f}°")

    def check_turn_completed(self):
        """Check apakah turn 90 derajat sudah selesai."""
        current_time = time.time()
        
        # Check timeout (safety)
        if (current_time - self.turn_start_time) > self.MAX_TURN_TIME:
            self.get_logger().warn("Turn 90° timeout!")
            return True
        
        # Hitung progress turn
        angle_diff = abs(normalize_angle(self.angle - self.turn_start_angle))
        
        # Check if completed (toleransi lebih longgar untuk simplicity)
        if angle_diff >= (90 - self.ANGLE_TOLERANCE):
            return True
            
        return False

    def reset_turn_90_variables(self):
        """Reset variabel untuk 90-degree turn."""
        self.is_turning_90 = False
        self.turn_start_angle = 0
        self.turn_target_angle = 0
        self.turn_start_time = 0
        self.turn_direction = 0
        self.turn_90_pid.reset()

    def rumus_kinematiks_improved(self, data_ly, data_lx):
        """Rumus kinematika yang diperbaiki dengan PWM selalu positif (0-1024)."""
        # Deadzone untuk joystick
        DEADZONE = 20
        
        # Normalisasi input joystick
        forward_input = data_ly - self.NEUTRAL_PWM
        turn_input = data_lx - self.NEUTRAL_PWM
        
        # Apply deadzone
        if abs(forward_input) < DEADZONE:
            forward_input = 0
        if abs(turn_input) < DEADZONE:
            turn_input = 0
        
        # Scale input dengan range yang lebih aman untuk menghindari nilai negatif
        # MAX_SAFE_RANGE dibatasi agar tidak melebihi neutral (512)
        MAX_SAFE_RANGE = min(self.MAX_PWM_RANGE, self.NEUTRAL_PWM - 50)  # 462 untuk safety margin
        
        forward_scaled = (forward_input / 511.0) * 511
        turn_scaled = (turn_input / 511.0) * 511
        
        # Differential drive calculation
        left_speed = forward_scaled - turn_scaled
        right_speed = forward_scaled + turn_scaled
        
        # Ensure minimum movement speed jika ada input
        if abs(left_speed) > 0 and abs(left_speed) < self.MIN_MOVEMENT_PWM:
            left_speed = self.MIN_MOVEMENT_PWM if left_speed > 0 else -self.MIN_MOVEMENT_PWM
        if abs(right_speed) > 0 and abs(right_speed) < self.MIN_MOVEMENT_PWM:
            right_speed = self.MIN_MOVEMENT_PWM if right_speed > 0 else -self.MIN_MOVEMENT_PWM
        
        # Convert to PWM values (add to neutral)
        motor_left = self.NEUTRAL_PWM - left_speed   # Reverse untuk kiri
        motor_right = self.NEUTRAL_PWM + right_speed
        
        # CRITICAL: Constrain ke range PWM valid (0-1024) - TIDAK BOLEH NEGATIF!
        motor_left = constrain(motor_left, 1, 1024)   # Safety margin dari 0 dan 1024
        motor_right = constrain(motor_right, 1, 1024)
        
        # Double check - pastikan tidak ada nilai negatif atau melebihi 1024
        motor_left = max(0, min(1024, motor_left))
        motor_right = max(0, min(1024, motor_right))
        
        return {
            'motor_left': int(motor_left),
            'motor_right': int(motor_right)
        }

    def process_auto_mode(self):
        """ENHANCED mode otomatis dengan target 5cm dan responsivitas tinggi."""
        current_time = time.time()
        dt = current_time - self.last_time
        self.last_time = current_time
        
        # Cek timeout deteksi
        detection_lost = (current_time - self.last_detection_time) > self.detection_timeout
        
        motor_speeds = {'motor_left': self.NEUTRAL_PWM, 'motor_right': self.NEUTRAL_PWM}

        # Menggunakan PID untuk menyesuaikan arah berdasarkan data angle
        angle_error = self.angle  # Menggunakan data angle dari MPU untuk mendeteksi error sudut
        angle_correction = self.turn_pid.calculate(0, angle_error, dt)  # Menyesuaikan PID dengan target sudut (0 untuk menuju ke target yang tepat)

        if self.bottle_detected == 1:
            # Objek terdeteksi - proses berdasarkan state
            if self.approach_state == "align":
                motor_speeds = self.align_to_object_enhanced()
                print(f"[AUTO] ALIGNING - Pos: {self.object_position}, Dist: {self.distance}cm")
                
            elif self.approach_state == "approach":
                motor_speeds = self.approach_object_fast()
                print(f"[AUTO] APPROACHING FAST - Dist: {self.distance}cm")
                
            elif self.approach_state == "fine_approach":
                motor_speeds = self.approach_object_fine()
                print(f"[AUTO] FINE APPROACH - Dist: {self.distance}cm -> Target: {self.TARGET_DISTANCE}cm")
                
            elif self.approach_state == "arrived":
                motor_speeds = {'motor_left': self.NEUTRAL_PWM, 'motor_right': self.NEUTRAL_PWM}
                print(f"[AUTO] ARRIVED - Target tercapai! Jarak: {self.distance}cm")
        
        elif detection_lost:
            # Objek hilang - mulai scanning yang agresif
            self.approach_state = "search"
            
            if not self.scanning_mode:
                self.scanning_mode = True
                self.scan_start_time = current_time
                print("[AUTO] SEARCHING - Memulai aggressive scanning")
            
            motor_speeds = self.scan_for_object_enhanced(current_time)
        
        else:
            # Tidak ada objek tapi belum timeout
            self.approach_state = "search"
            motor_speeds = {'motor_left': self.NEUTRAL_PWM, 'motor_right': self.NEUTRAL_PWM}

        # Apply angle correction to maintain the correct heading
        motor_speeds['motor_left'] += int(angle_correction)  # Koreksi untuk motor kiri
        motor_speeds['motor_right'] -= int(angle_correction)  # Koreksi untuk motor kanan
        
        # CRITICAL: Ensure PWM values stay positive after correction
        motor_speeds['motor_left'] = constrain(motor_speeds['motor_left'], 1, 1024)
        motor_speeds['motor_right'] = constrain(motor_speeds['motor_right'], 1, 1024)
        
        # Double check - pastikan tidak ada nilai negatif
        motor_speeds['motor_left'] = max(0, min(1024, motor_speeds['motor_left']))
        motor_speeds['motor_right'] = max(0, min(1024, motor_speeds['motor_right']))

        # Smooth speed transition untuk transisi halus
        motor_speeds = self.smooth_motor_transition(motor_speeds)
        self.send_data_to_esp32(motor_speeds)

    def align_to_object_enhanced(self):
        """ENHANCED alignment dengan PWM selalu positif."""
        if self.object_position == "left":
            # Objek di kiri, putar kiri dengan kecepatan tinggi
            motor_left = self.NEUTRAL_PWM - self.ALIGN_SPEED
            motor_right = self.NEUTRAL_PWM + self.ALIGN_SPEED
            
        elif self.object_position == "right":
            # Objek di kanan, putar kanan dengan kecepatan tinggi
            motor_left = self.NEUTRAL_PWM + self.ALIGN_SPEED
            motor_right = self.NEUTRAL_PWM - self.ALIGN_SPEED
            
        else:
            # Center - lanjut ke approach
            if self.distance > self.FINE_APPROACH_DISTANCE:
                self.approach_state = "approach"
            else:
                self.approach_state = "fine_approach"
            motor_left = self.NEUTRAL_PWM
            motor_right = self.NEUTRAL_PWM
        
        # CRITICAL: Constrain values - pastikan selalu positif!
        motor_left = constrain(motor_left, 1, 1024)   # Safety margin
        motor_right = constrain(motor_right, 1, 1024)
        
        # Double check
        motor_left = max(0, min(1024, motor_left))
        motor_right = max(0, min(1024, motor_right))
        
        return {'motor_left': int(motor_left), 'motor_right': int(motor_right)}

    def approach_object_fast(self):
        """Approach cepat untuk jarak jauh dengan PWM selalu positif."""
        # Jika objek tidak center, kembali ke align
        if self.object_position != "center":
            self.approach_state = "align"
            return self.align_to_object_enhanced()
        
        # Jika sudah dekat, switch ke fine approach
        if self.distance <= self.FINE_APPROACH_DISTANCE:
            self.approach_state = "fine_approach"
            return self.approach_object_fine()
        
        # Approach dengan kecepatan tinggi
        speed = self.APPROACH_SPEED_FAST
        
        motor_left = self.NEUTRAL_PWM - speed
        motor_right = self.NEUTRAL_PWM + speed
        
        # CRITICAL: Constrain - pastikan selalu positif!
        motor_left = constrain(motor_left, 1, 1024)
        motor_right = constrain(motor_right, 1, 1024)
        
        # Double check
        motor_left = max(0, min(1024, motor_left))
        motor_right = max(0, min(1024, motor_right))
        
        return {'motor_left': int(motor_left), 'motor_right': int(motor_right)}

    def approach_object_fine(self):
        """Fine approach untuk mencapai target 5cm dengan PWM selalu positif."""
        # Jika objek tidak center, kembali ke align
        if self.object_position != "center":
            self.approach_state = "align"
            return self.align_to_object_enhanced()
        
        # Jika terlalu dekat dari stop distance, berhenti
        if self.distance <= self.STOP_DISTANCE:
            self.approach_state = "arrived"
            return {'motor_left': self.NEUTRAL_PWM, 'motor_right': self.NEUTRAL_PWM}
        
        # Jika sudah mencapai target distance, berhenti
        if self.distance <= self.TARGET_DISTANCE:
            self.approach_state = "arrived"
            return {'motor_left': self.NEUTRAL_PWM, 'motor_right': self.NEUTRAL_PWM}
        
        # Hitung kecepatan berdasarkan jarak dengan scaling yang halus
        distance_error = self.distance - self.TARGET_DISTANCE
        
        # Linear scaling dengan batas minimum dan maksimum
        if distance_error > 10:
            speed = self.APPROACH_SPEED_SLOW
        else:
            # Scaling halus untuk jarak dekat
            speed_ratio = distance_error / 10.0
            speed = max(self.MIN_MOVEMENT_PWM, int(self.MIN_MOVEMENT_PWM + 
                       (self.APPROACH_SPEED_SLOW - self.MIN_MOVEMENT_PWM) * speed_ratio))
        
        motor_left = self.NEUTRAL_PWM - speed
        motor_right = self.NEUTRAL_PWM + speed
        
        # CRITICAL: Constrain - pastikan selalu positif!
        motor_left = constrain(motor_left, 1, 1024)
        motor_right = constrain(motor_right, 1, 1024)
        
        # Double check
        motor_left = max(0, min(1024, motor_left))
        motor_right = max(0, min(1024, motor_right))
        
        return {'motor_left': int(motor_left), 'motor_right': int(motor_right)}

    def scan_for_object_enhanced(self, current_time):
        """Enhanced scanning dengan PWM selalu positif."""
        # Hitung waktu dalam cycle scan
        scan_elapsed = current_time - self.scan_start_time
        cycle_time = scan_elapsed % (self.scan_duration * 2)
        
        # Scan dengan kecepatan tinggi
        scan_speed = self.TURN_SPEED + 50  # Lebih cepat dari turn biasa
        
        if cycle_time < self.scan_duration:
            # Scan ke kanan
            motor_left = self.NEUTRAL_PWM + scan_speed
            motor_right = self.NEUTRAL_PWM - scan_speed
            direction_text = "KANAN"
        else:
            # Scan ke kiri
            motor_left = self.NEUTRAL_PWM - scan_speed
            motor_right = self.NEUTRAL_PWM + scan_speed
            direction_text = "KIRI"
        
        # CRITICAL: Constrain - pastikan selalu positif!
        motor_left = constrain(motor_left, 1, 1024)
        motor_right = constrain(motor_right, 1, 1024)
        
        # Double check
        motor_left = max(0, min(1024, motor_left))
        motor_right = max(0, min(1024, motor_right))
        
        # Print setiap 20 cycle untuk mengurangi spam
        if int(scan_elapsed * 10) % 20 == 0:
            print(f"[AUTO] AGGRESSIVE SCAN {direction_text} - Elapsed: {scan_elapsed:.1f}s")
        
        return {'motor_left': int(motor_left), 'motor_right': int(motor_right)}

    def smooth_motor_transition(self, target_speeds):
        """Enhanced smooth transition untuk responsivitas tinggi."""
        # Smoothing factor lebih responsif
        alpha = self.speed_smoothing
        
        # Linear interpolation
        new_left = self.current_motor_left + alpha * (target_speeds['motor_left'] - self.current_motor_left)
        new_right = self.current_motor_right + alpha * (target_speeds['motor_right'] - self.current_motor_right)
        
        # Update current values
        self.current_motor_left = new_left
        self.current_motor_right = new_right
        
        return {'motor_left': int(new_left), 'motor_right': int(new_right)}

    def reset_auto_mode_variables(self):
        """Reset variabel mode otomatis."""
        self.target_locked = False
        self.recovery_mode = False
        self.scanning_mode = False
        self.scan_direction = 1
        self.approach_state = "search"
        self.current_motor_left = self.NEUTRAL_PWM
        self.current_motor_right = self.NEUTRAL_PWM
        self.turn_pid.reset()
        self.distance_pid.reset()
        self.last_time = time.time()
        self.last_detection_time = time.time()
        self.scan_start_time = time.time()
        self.debug_counter = 0

    def parse_data(self, raw_data):
        """Parse data dari ESP32."""
        try:
            content = raw_data[1:-1]
            parts = content.split(' ')
            
            if len(parts) != 22:
                return None
            
            return [int(part) for part in parts]
        except Exception as e:
            self.get_logger().error(f"Error parsing data: {e}")
            return None

    def send_data_to_esp32(self, motor_speeds):
        """Kirim data ke ESP32."""
        try:
            if self.serial_connection and self.serial_connection.is_open:
                motor_left = motor_speeds['motor_left']
                motor_right = motor_speeds['motor_right']
                
                # Store last motor commands for odometry
                self.last_motor_left = motor_left
                self.last_motor_right = motor_right
                
                data_to_send = f"*{motor_left} {motor_right}#"
                self.serial_connection.write(data_to_send.encode('utf-8'))
                
                # Debug output dengan format yang lebih jelas
                if not self.menu_mode and self.current_mode == 'auto':
                    if self.debug_counter % 20 == 0:  # Print setiap 20 cycle
                        print(f"[MOTOR] L:{motor_left:04d} R:{motor_right:04d} | "
                              f"State:{self.approach_state} | Dist:{self.distance}cm")

        except Exception as e:
            self.get_logger().error(f"Error mengirim data ke ESP32: {e}")

    def send_default_data(self):
        """Kirim data default (diam) ke ESP32."""
        if self.serial_connection and self.serial_connection.is_open:
            try:
                # Store neutral as last motor commands
                self.last_motor_left = self.NEUTRAL_PWM
                self.last_motor_right = self.NEUTRAL_PWM
                
                data_to_send = f"*{self.NEUTRAL_PWM} {self.NEUTRAL_PWM}#"
                self.serial_connection.write(data_to_send.encode('utf-8'))
            except Exception as e:
                self.get_logger().error(f"Error mengirim data default: {e}")

def show_menu():
    """Tampilkan menu pemilihan mode."""
    import os
    os.system('clear' if os.name == 'posix' else 'cls')
    
    print("\n" + "="*60)
    print("          ENHANCED ROBOT CONTROL SYSTEM")
    print("="*60)
    print("Pilih mode operasi:")
    print("1. Manual Mode   - Kontrol dengan joystick + Turn 90°")
    print("2. Auto Mode     - Deteksi objek otomatis (Target: 5cm)")
    print("\nTekan tombol pada controller:")
    print("- SILANG untuk Manual Mode")
    print("- BULAT untuk Auto Mode")
    print("- SELECT untuk kembali ke menu")
    print("="*60)

def main(args=None):
    rclpy.init(args=args)
    
    # Tampilkan menu
    show_menu()
    
    try:
        # Start dengan mode menu
        node = OlahNode('manual')
        
        print("\nMenunggu input dari controller...")
        print("Tekan SILANG untuk Manual atau BULAT untuk Auto")
        
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\nProgram dihentikan oleh user")
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()