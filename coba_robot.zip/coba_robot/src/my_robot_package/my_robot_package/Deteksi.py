import threading
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import os
import cv2
import cvzone
import math
import time
from ultralytics import YOLO
import logging

class DetectionNode(Node):
    def __init__(self):
        super().__init__('detection_node')

        # Publisher untuk mengirim status deteksi ke Olah.py
        self.publisher = self.create_publisher(String, '/object_status', 10)

        # Set video capture device
        self.cap = cv2.VideoCapture(2)  # For Webcam
        self.cap.set(3, 360)
        self.cap.set(4, 240)

        # Menonaktifkan output verbose dari YOLO
        os.environ['YOLO_VERBOSE'] = 'False'
        logging.getLogger('ultralytics').setLevel(logging.ERROR)

        # Load YOLO model with your custom weights
        self.model = YOLO("src/my_robot_package/my_robot_package/tes.pt", verbose=False)

        # Define the class name for plastic bottles
        self.classNames = ["bottle"]

        # Confidence threshold (only objects with confidence > 0.7 will be detected)
        self.confidence_threshold = 0.7

        # Start the detection in a separate thread
        self.detection_thread = threading.Thread(target=self.run_detection)
        self.detection_thread.start()

    def run_detection(self):
        prev_frame_time = 0
        new_frame_time = 0

        while rclpy.ok():
            new_frame_time = time.time()

            # Capture frame from webcam
            success, img = self.cap.read()
            if not success:
                break

            # Perform object detection with YOLO model
            results = self.model(img, stream=True)

            # Variables to send to Olah.py
            object_position = "none"  # will hold 'left' or 'right' or 'center'
            bottle_detected = 0  # Bottle detection flag
            confidence_score = 0.0  # To store the highest confidence score

            # Draw crosshair (small circle at the center of the frame)
            h, w, _ = img.shape
            center_coordinates = (w // 2, h // 2)
            cv2.circle(img, center_coordinates, 10, (0, 255, 0), 2)  # Draw circle (crosshair)

            # Loop over the results and draw bounding boxes
            for r in results:
                boxes = r.boxes
                for box in boxes:
                    # Bounding Box Coordinates
                    x1, y1, x2, y2 = box.xyxy[0]
                    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

                    # Draw rectangle around detected object
                    w_box, h_box = x2 - x1, y2 - y1
                    cvzone.cornerRect(img, (x1, y1, w_box, h_box))

                    # Calculate center of the bounding box
                    center_x = int((x1 + x2) / 2)
                    center_y = int((y1 + y2) / 2)

                    # Draw a small circle in the center of the bounding box (red dot)
                    cv2.circle(img, (center_x, center_y), 5, (0, 0, 255), -1)

                    # Confidence score
                    conf = math.ceil((box.conf[0] * 100)) / 100

                    # Class label
                    cls = int(box.cls[0])

                    # Filter detections by confidence threshold
                    if self.classNames[cls] == "bottle" and conf >= self.confidence_threshold:
                        bottle_detected = 1
                        # Position relative to crosshair
                        object_position = "center" if x1 < center_coordinates[0] < x2 and y1 < center_coordinates[1] < y2 else "left" if center_x < w // 2 else "right"
                        confidence_score = max(confidence_score, conf)  # Store the highest confidence

                    # Put class name and confidence score on the image
                    cvzone.putTextRect(img, f'{self.classNames[cls]} {conf}', (max(0, x1), max(35, y1)), scale=1, thickness=1)

            # Publish the object status (position, bottle detection flag, and confidence score)
            msg = String()
            msg.data = f'{bottle_detected} {object_position} {confidence_score}'  # Mengirim format "status deteksi posisi objek confidence"
            self.publisher.publish(msg)

            # Calculate FPS (frames per second)
            fps = 1 / (new_frame_time - prev_frame_time)
            prev_frame_time = new_frame_time

            # Show the result
            cv2.imshow("Image", img)

            # Wait for key press to exit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        # Release the video capture object and close windows
        self.cap.release()
        cv2.destroyAllWindows()

def main(args=None):
    rclpy.init(args=args)
    node = DetectionNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

