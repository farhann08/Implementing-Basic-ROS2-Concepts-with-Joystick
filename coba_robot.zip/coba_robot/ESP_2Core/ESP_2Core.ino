#include <Ps3Controller.h>
#include "Arduino.h"
#include "MPU6050_6Axis_MotionApps20.h"
#include "Wire.h"
#include "I2Cdev.h"

// ==================== MOTOR DRIVER PIN DEFINITIONS ====================
#define IN1 2    // Motor 1 IN1 pin
#define IN2 4   // Motor 1 IN2 pin
#define IN3 5   // Motor 2 IN3 pin
#define IN4 18   // Motor 2 IN4 pin

// MPU6050 setup
MPU6050 mpu(0x68);  // MPU6050 dengan alamat I2C 0x68

bool dmpReady = false;
uint8_t mpuIntStatus;
uint8_t devStatus;
uint16_t packetSize;
uint16_t fifoCount;
uint8_t fifoBuffer[64];

Quaternion q;
VectorInt16 aa;
VectorInt16 gy;
VectorInt16 aaReal;
VectorInt16 aaWorld;
VectorFloat gravity;
float ypr[3];  // hanya untuk yaw

// Ultrasonic sensor HC-SR04 setup
#define TRIG_PIN 12  // Pin untuk Trig (GPIO18)
#define ECHO_PIN 14  // Pin untuk Echo (GPIO19)

long duration;
int distance;

volatile bool mpuInterrupt = false;

void dmpDataReady() {
  mpuInterrupt = true;
}

int Angle_Yaw = 0;
float yaw_offset = 0.0;
bool reset_requested = false;

// PWM Settings
const int PWM_FREQ = 1000;
const int PWM_RESOLUTION = 8;

// ==================== PS3 CONTROLLER VARIABLES ====================
int PWML2 = 0, PWMR2 = 0;  // PWM values for L2 and R2 buttons
int Segitiga = 0, Bulat = 0, Silang = 0, Kotak = 0; // Basic buttons
int Atas = 0, Kanan = 0, Kiri = 0, Bawah = 0; // Direction buttons
int L1 = 0, L2 = 0, R1 = 0, R2 = 0; 
int Select = 0, Start = 0;                    // Additional buttons
int LStickY = 0, LStickX = 0;                 // Left joystick
int RStickY = 0, RStickX = 0;                 // Right joystick

char dataPWM1[5], dataPWM2[5], dataLY[5], dataLX[5], dataRY[5], dataRX[5], dataJarak[5], dataAngle[4];
String KirimPC;

// ==================== MOTOR CONTROL VARIABLES ====================
typedef struct {
    bool enable;
    char raw_data[30];  // Increase buffer size
    char Data1[6];      // Increase to handle 5-digit numbers + null terminator
    char Data2[6];      // Increase to handle 5-digit numbers + null terminator
    volatile uint8_t index;
    volatile bool dataReady;
} Data_Typedef;

Data_Typedef DataMINIPC = {.enable = true, .index = 0, .dataReady = false};
int pwm1 = 0, pwm2 = 0; // PWM values for motors

// ==================== TASK HANDLES ====================
TaskHandle_t PS3Task;
TaskHandle_t MotorTask;

// ==================== SETUP FUNCTION ====================
void setup() {
    Serial.begin(115200);
    // Inisialisasi I2C untuk MPU6050
    Wire.begin();
    mpu.initialize();
    Serial.println("\n=== ESP32 Dual Core Robot Controller (Fixed) ===");

    // Inisialisasi pin untuk Ultrasonic Sensor
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);

    // Tes koneksi dengan sensor MPU6050
    Serial.println(F("Testing device connections..."));
    Serial.println(mpu.testConnection() ? F("MPU6050 connection successful") : F("MPU6050 connection failed"));

    // Inisialisasi DMP untuk MPU6050
    devStatus = mpu.dmpInitialize();
    
    // Kalibrasi MPU6050
    mpu.setXGyroOffset(79);
    mpu.setYGyroOffset(-226);
    mpu.setZGyroOffset(51);
    mpu.setXAccelOffset(-7500);
    mpu.setYAccelOffset(-6622);
    mpu.setZAccelOffset(9616);

    if (devStatus == 0) {
    mpu.CalibrateAccel(6);
    mpu.CalibrateGyro(6);
    mpu.PrintActiveOffsets();
    mpu.setDMPEnabled(true);
    attachInterrupt(digitalPinToInterrupt(5), dmpDataReady, RISING);  // Interrupt untuk DMP
    mpuIntStatus = mpu.getIntStatus();
    dmpReady = true;
    packetSize = mpu.dmpGetFIFOPacketSize();
    } else {
      Serial.print(F("DMP Initialization failed (code "));
      Serial.print(devStatus);
      Serial.println(F(")"));
    }

    // Initialize hardware
    initializeMotors();
    initializePS3Controller();
    initializeSerial();
    
    delay(2000); // Allow time for initialization
    
    // Create dual core tasks
    createTasks();
    
    Serial.println("System initialized successfully!");
    Serial.println("Core 0: Motor Control | Core 1: PS3 Controller");
}

void loop() {
    // Main loop monitors system health
    vTaskDelay(pdMS_TO_TICKS(2000));
    // Serial.println("System running...");
}

// ==================== MOTOR CONTROL FUNCTIONS ====================
void initializeMotors() {
    // Setup PWM for all motor pins using new ESP32 API
    ledcAttach(IN1, PWM_FREQ, PWM_RESOLUTION);
    ledcAttach(IN2, PWM_FREQ, PWM_RESOLUTION);
    ledcAttach(IN3, PWM_FREQ, PWM_RESOLUTION);
    ledcAttach(IN4, PWM_FREQ, PWM_RESOLUTION);

    // Stop all motors initially
    stopAllMotors();
    Serial.println("Motors initialized with ledcAttach");
}

void initializePS3Controller() {
    Ps3.begin("a0:a3:b3:ab:d4:d9"); // Change to your controller's MAC address
    Serial.println("PS3 Controller initialized");
    Serial.println("MAC Address: a0:a3:b3:ab:d4:d9");
    Serial.println("Waiting for PS3 controller connection...");
}

void initializeSerial() {
    strcpy(DataMINIPC.Data1, "0512");  // Default center value
    strcpy(DataMINIPC.Data2, "0512");  // Default center value
    DataMINIPC.index = 0;
    DataMINIPC.dataReady = false;
    Serial.println("Serial data initialized");
}

void createTasks() {
    // Create Motor Control Task on Core 0 (higher priority)
    xTaskCreatePinnedToCore(
        MotorControlTask,     // Task function
        "MotorTask",          // Task name
        8192,                 // Stack size (increased)
        NULL,                 // Parameters
        2,                    // Priority (higher for motor control)
        &MotorTask,           // Task handle
        0                     // Core 0
    );
    
    // Create PS3 Controller Task on Core 1
    xTaskCreatePinnedToCore(
        PS3ControllerTask,    // Task function
        "PS3Task",            // Task name
        8192,                 // Stack size (increased)
        NULL,                 // Parameters
        1,                    // Priority
        &PS3Task,             // Task handle
        1                     // Core 1
    );
    
    Serial.println("Tasks created successfully");
}

// ==================== CORE 1: PS3 CONTROLLER TASK ====================
void PS3ControllerTask(void *pvParameters) {
    Serial.println("PS3 Controller Task started on Core: " + String(xPortGetCoreID()));

    unsigned long lastSendTime = 0;
    const unsigned long SEND_INTERVAL = 50; // 20Hz update rate

    for(;;) {
        unsigned long currentTime = millis();

        if (currentTime - lastSendTime >= SEND_INTERVAL) {
            if (Ps3.isConnected()) {
                readPS3Data();

                // Deteksi edge detection untuk single button press
                static bool last_segitiga_state = false;
                if (Segitiga == 1 && !last_segitiga_state) { // Rising edge detection
                    reset_requested = true;  // Request reset pada rising edge
                }
                last_segitiga_state = Segitiga;

                GetYAWRobot();  // Selalu jalankan pembacaan yaw
                GetDistance();
                formatAndSendData();
            } else {
                sendDefaultData();
            }

            Serial.println(KirimPC);
            lastSendTime = currentTime;
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}


void readPS3Data() {
    // Digital buttons
    Silang = Ps3.data.button.cross ? 1 : 0;
    Segitiga = Ps3.data.button.triangle ? 1 : 0;
    Bulat = Ps3.data.button.circle ? 1 : 0;
    Kotak = Ps3.data.button.square ? 1 : 0;

    Atas = Ps3.data.button.up ? 1 : 0;
    Kanan = Ps3.data.button.right ? 1 : 0;
    Kiri = Ps3.data.button.left ? 1 : 0;
    Bawah = Ps3.data.button.down ? 1 : 0;

    L1 = Ps3.data.button.l1 ? 1 : 0;
    L2 = Ps3.data.analog.button.l2 > 60 ? 1 : 0;
    R1 = Ps3.data.button.r1 ? 1 : 0;
    R2 = Ps3.data.analog.button.r2 > 60 ? 1 : 0;

    Select = Ps3.data.button.select ? 1 : 0;
    Start = Ps3.data.button.start ? 1 : 0;

    // Analog values with bounds checking
    PWML2 = map(constrain(Ps3.data.analog.button.l2, 0, 255), 0, 255, 0, 1024);
    PWMR2 = map(constrain(Ps3.data.analog.button.r2, 0, 255), 0, 255, 0, 1024);
    LStickX = map(constrain(Ps3.data.analog.stick.lx, -128, 127), -128, 127, 0, 1024);
    LStickY = map(constrain(Ps3.data.analog.stick.ly, -128, 127), 127, -128, 0, 1024);
    RStickX = map(constrain(Ps3.data.analog.stick.rx, -128, 127), -128, 127, 0, 1024);
    RStickY = map(constrain(Ps3.data.analog.stick.ry, -128, 127), 127, -128, 0, 1024);
}

void GetYAWRobot() {
    if (!dmpReady) return;

    // Ambil paket FIFO dari DMP
    if (mpu.dmpGetCurrentFIFOPacket(fifoBuffer)) {
        // Mengambil data quaternion dan gravitasi
        mpu.dmpGetQuaternion(&q, fifoBuffer);
        mpu.dmpGetGravity(&gravity, &q);
        mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);

        // Konversi hasil ke derajat (yaw)
        float raw_yaw = -(ypr[0] * 180 / M_PI);

        // Proses reset jika diminta
        if (reset_requested) {
            yaw_offset = raw_yaw;  // Simpan posisi saat ini sebagai offset
            reset_requested = false;
        }

        // Hitung angle dengan offset
        Angle_Yaw = raw_yaw - yaw_offset;

        // Normalisasi nilai yaw dalam rentang 0 - 360 derajat
        while (Angle_Yaw < 0) {
            Angle_Yaw += 360;
        }
        while (Angle_Yaw >= 360) {
            Angle_Yaw -= 360;
        }
    }
}


void GetDistance() {
  // Mengirimkan pulsa untuk memulai pengukuran jarak
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);  // Menunggu selama 10 mikrodetik
  digitalWrite(TRIG_PIN, LOW);
  
  // Membaca durasi echo
  duration = pulseIn(ECHO_PIN, HIGH);
  
  // Menghitung jarak berdasarkan durasi
  distance = duration * 0.0344 / 2;  // Kecepatan suara adalah 0.0344 cm/mikrodetik
}

void formatAndSendData() {
    // Format data with proper zero-padding
    snprintf(dataPWM1, sizeof(dataPWM1), "%04d", PWML2);
    snprintf(dataPWM2, sizeof(dataPWM2), "%04d", PWMR2);
    snprintf(dataLY, sizeof(dataLY), "%04d", LStickY);
    snprintf(dataLX, sizeof(dataLX), "%04d", LStickX);
    snprintf(dataRY, sizeof(dataRY), "%04d", RStickY);
    snprintf(dataRX, sizeof(dataRX), "%04d", RStickX);
    snprintf(dataJarak, sizeof(dataJarak), "%04d", distance);
    snprintf(dataAngle, sizeof(dataAngle), "%03d", Angle_Yaw);

    KirimPC = "*" + String(Segitiga) + " " + String(Bulat) + " " + String(Silang) + " " + String(Kotak) + " "
              + String(Atas) + " " + String(Kanan) + " " + String(Bawah) + " " + String(Kiri) + " "
              + String(L1) + " " + String(L2) + " " + String(R1) + " " + String(R2) + " "
              + String(Select) + " " + String(Start) + " "
              + String(dataPWM1) + " " + String(dataPWM2) + " "
              + String(dataLY) + " " + String(dataLX) + " " + String(dataRY) + " " + String(dataRX) + " " + String(dataJarak) + " " + String(dataAngle) + "#";
}

void sendDefaultData() {
    KirimPC = "*0 0 0 0 0 0 0 0 0 0 0 0 0 0 0000 0000 0512 0512 0512 0512 0000 000#";
}

// ==================== CORE 0: MOTOR CONTROL TASK ====================
void MotorControlTask(void *pvParameters) {
    Serial.println("Motor Control Task started on Core: " + String(xPortGetCoreID()));

    for(;;) {
        readSerialDataImproved();

        if (DataMINIPC.dataReady) {
            processMotorData();
            executeMotorControl();
            DataMINIPC.dataReady = false;
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void readSerialDataImproved() {
    static String serialBuffer = "";
    static bool receivingData = false;

    while (Serial.available() > 0) {
        char inChar = Serial.read();

        if (inChar == '*') {
            serialBuffer = "";
            receivingData = true;
            Serial.println("Start receiving data...");
        }
        else if (inChar == '#' && receivingData) {
            if (serialBuffer.length() > 0) {
                Serial.println("Raw received: " + serialBuffer);
                parseSerialData(serialBuffer);
                DataMINIPC.dataReady = true;
            }
            receivingData = false;
        }
        else if (receivingData && serialBuffer.length() < 30) { // Increase buffer size
            serialBuffer += inChar;
        }
    }
}

void parseSerialData(String data) {
    Serial.println("Parsing data: " + data);
    
    int spaceIndex = data.indexOf(' ');

    if (spaceIndex > 0 && spaceIndex < data.length() - 1) {
        String motor1Str = data.substring(0, spaceIndex);
        String motor2Str = data.substring(spaceIndex + 1);
        
        Serial.println("Motor1 string: " + motor1Str);
        Serial.println("Motor2 string: " + motor2Str);

        // Accept up to 5 characters (for 5-digit numbers like 02048)
        if (motor1Str.length() <= 5 && motor2Str.length() <= 5) {
            strncpy(DataMINIPC.Data1, motor1Str.c_str(), 6); // Increase buffer
            strncpy(DataMINIPC.Data2, motor2Str.c_str(), 6);
            DataMINIPC.Data1[5] = '\0';
            DataMINIPC.Data2[5] = '\0';
            
            Serial.println("Parsed Motor1: " + String(DataMINIPC.Data1));
            Serial.println("Parsed Motor2: " + String(DataMINIPC.Data2));
        } else {
            Serial.println("Invalid motor string lengths");
        }
    } else {
        Serial.println("Space not found or invalid position");
    }
}

void processMotorData() {
    int rawPwm1 = atoi(DataMINIPC.Data1);
    int rawPwm2 = atoi(DataMINIPC.Data2);
    
    Serial.printf("Raw PWM values: PWM1=%d, PWM2=%d\n", rawPwm1, rawPwm2);
    
    // Convert from 0-2048 range to -255 to +255 range
    // 1024 should be center (0), 0 should be -255, 2048 should be +255
    pwm1 = mapToMotorPWM(rawPwm1);
    pwm2 = mapToMotorPWM(rawPwm2);
    
    Serial.printf("Final PWM values: PWM1=%d, PWM2=%d\n", pwm1, pwm2);
}

int mapToMotorPWM(int value) {
    // Constrain input to valid range
    value = constrain(value, 0, 2048);
    
    // Map 0-2048 to -255 to +255, with 1024 as center (0)
    // 0 -> -255, 1024 -> 0, 2048 -> +255
    int result = map(value, 0, 2048, -255, 255);
    
    // Apply deadzone around center to avoid jitter
    if (abs(result) < 10) {
        result = 0;
    }
    
    return result;
}

void executeMotorControl() {
    Serial.printf("Executing motor control: M1=%d, M2=%d\n", pwm1, pwm2);
    driveMotor1(pwm1);
    driveMotor2(pwm2);
}

void driveMotor1(int pwm) {
    pwm = constrain(pwm, -255, 255);
    
    Serial.printf("Driving Motor1 with PWM: %d\n", pwm);
    
    if (pwm > 0) {
        // Forward direction
        ledcWrite(IN1, pwm);
        ledcWrite(IN2, 0);
        Serial.printf("Motor1 Forward: IN1=%d, IN2=0\n", pwm);
    } else if (pwm < 0) {
        // Reverse direction
        ledcWrite(IN1, 0);
        ledcWrite(IN2, abs(pwm));
        Serial.printf("Motor1 Reverse: IN1=0, IN2=%d\n", abs(pwm));
    } else {
        // Stop
        ledcWrite(IN1, 0);
        ledcWrite(IN2, 0);
        Serial.println("Motor1 Stop");
    }
}

void driveMotor2(int pwm) {
    pwm = constrain(pwm, -255, 255);
    
    Serial.printf("Driving Motor2 with PWM: %d\n", pwm);
    
    if (pwm > 0) {
        // Forward direction
        ledcWrite(IN3, pwm);
        ledcWrite(IN4, 0);
        Serial.printf("Motor2 Forward: IN3=%d, IN4=0\n", pwm);
    } else if (pwm < 0) {
        // Reverse direction
        ledcWrite(IN3, 0);
        ledcWrite(IN4, abs(pwm));
        Serial.printf("Motor2 Reverse: IN3=0, IN4=%d\n", abs(pwm));
    } else {
        // Stop
        ledcWrite(IN3, 0);
        ledcWrite(IN4, 0);
        Serial.println("Motor2 Stop");
    }
}

void stopAllMotors() {
    ledcWrite(IN1, 0);
    ledcWrite(IN2, 0);
    ledcWrite(IN3, 0);
    ledcWrite(IN4, 0);
    Serial.println("All motors stopped");
}
