#include "MPU6050_6Axis_MotionApps20.h"
#include "Wire.h"
#include "I2Cdev.h"

// MPU6050 setup
MPU6050 mpu(0x68);  // MPU6050 dengan alamat I2C 0x68

bool dmpReady = false;
uint8_t mpuIntStatus;
uint8_t devStatus;
uint16_t packetSize;
uint16_t fifoCount;
uint8_t fifoBuffer[64];

// variabel orientasi dan gerakan
Quaternion q;
VectorInt16 aa;
VectorInt16 gy;
VectorInt16 aaReal;
VectorInt16 aaWorld;
VectorFloat gravity;
float ypr[3];  // hanya untuk yaw

// Ultrasonic sensor HC-SR04 setup
#define TRIG_PIN 18  // Pin untuk Trig (GPIO18)
#define ECHO_PIN 19  // Pin untuk Echo (GPIO19)

long duration;
int distance;

volatile bool mpuInterrupt = false;

void dmpDataReady() {
  mpuInterrupt = true;
}

int Angle_Yaw = 0;

void setup() {
  Serial.begin(115200);
  
  // Inisialisasi I2C untuk MPU6050
  Wire.begin();
  mpu.initialize();
  
  // Inisialisasi pin untuk Ultrasonic Sensor
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  
  // Tes koneksi dengan sensor MPU6050
  Serial.println(F("Testing device connections..."));
  Serial.println(mpu.testConnection() ? F("MPU6050 connection successful") : F("MPU6050 connection failed"));

  // Inisialisasi DMP untuk MPU6050
  devStatus = mpu.dmpInitialize();
  
  // Kalibrasi MPU6050
  mpu.setXGyroOffset(79);
  mpu.setYGyroOffset(-226);
  mpu.setZGyroOffset(51);
  mpu.setXAccelOffset(-7500);
  mpu.setYAccelOffset(-6622);
  mpu.setZAccelOffset(9616);

  if (devStatus == 0) {
    mpu.CalibrateAccel(6);
    mpu.CalibrateGyro(6);
    mpu.PrintActiveOffsets();
    mpu.setDMPEnabled(true);
    attachInterrupt(digitalPinToInterrupt(5), dmpDataReady, RISING);  // Interrupt untuk DMP
    mpuIntStatus = mpu.getIntStatus();
    dmpReady = true;
    packetSize = mpu.dmpGetFIFOPacketSize();
  } else {
    Serial.print(F("DMP Initialization failed (code "));
    Serial.print(devStatus);
    Serial.println(F(")"));
  }
}

void GetYAWRobot() {
  if (!dmpReady) return;

  // Ambil paket FIFO dari DMP
  if (mpu.dmpGetCurrentFIFOPacket(fifoBuffer)) {
    // Mengambil data quaternion dan gravitasi
    mpu.dmpGetQuaternion(&q, fifoBuffer);
    mpu.dmpGetGravity(&gravity, &q);
    mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);  // Hitung yaw saja

    // Konversi hasil ke derajat (yaw)
    Angle_Yaw = -(ypr[0] * 180 / M_PI);  // Negatif untuk mengoreksi orientasi yaw

    // Membatasi nilai yaw dalam rentang 0 - 360 derajat
    if (Angle_Yaw > 359) {
      Angle_Yaw -= 360;
    } else if (Angle_Yaw < 0) {
      Angle_Yaw += 360;
    }
  }
}

void GetDistance() {
  // Mengirimkan pulsa untuk memulai pengukuran jarak
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);  // Menunggu selama 10 mikrodetik
  digitalWrite(TRIG_PIN, LOW);
  
  // Membaca durasi echo
  duration = pulseIn(ECHO_PIN, HIGH);
  
  // Menghitung jarak berdasarkan durasi
  distance = duration * 0.0344 / 2;  // Kecepatan suara adalah 0.0344 cm/mikrodetik
}

void loop() {
  GetYAWRobot();
  GetDistance();

  // Menampilkan hasil yaw dan jarak di Serial Monitor
  Serial.print("Yaw: ");
  Serial.print(Angle_Yaw);
  Serial.print(" | ");
  Serial.print("jarak: ");
  Serial.println(distance);

  delay(100);  // Tunggu 100ms sebelum pembacaan berikutnya
}
